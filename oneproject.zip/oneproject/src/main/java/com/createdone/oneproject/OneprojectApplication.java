package com.createdone.oneproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OneprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(OneprojectApplication.class, args);
	}

}
